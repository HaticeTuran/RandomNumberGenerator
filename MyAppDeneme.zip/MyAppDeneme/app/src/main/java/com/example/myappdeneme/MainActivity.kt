package com.example.myappdeneme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val text: TextView = findViewById(R.id.textView2)
        val button : Button = findViewById(R.id.button)
        text.text = "Click Button for a random number "
        button.setOnClickListener {
            text.text = (1..10).random().toString()
        }

    }
}